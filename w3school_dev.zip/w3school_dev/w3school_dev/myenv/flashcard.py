from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def indexPage():
    return render_template(
        "index.html"
    )
    
@app.route("/course")
def coursePage():
    return render_template(
        "course.html"
    )

@app.route("/courses")
def courseSPage():       
    return render_template(
        "courses.html"
    )
    
if __name__=="__name__":
    app.run(debug=True)